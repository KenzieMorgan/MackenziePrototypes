using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerScript : MonoBehaviour
{

    public float mSpeed;

    public float turnSpeed;

    public float jumpForce;

    public float gravityValue;

    public Rigidbody rBody;

    private Vector3 playerVelocity;

    public bool isGrounded;
    public bool doubleJump;
    public bool wallJump;

    public CharacterController controller;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

        movement();
        jump();
        close();
        playerVelocity.y += gravityValue * Time.deltaTime;
        controller.Move(playerVelocity * Time.deltaTime);

    }
    void movement()
    {

        isGrounded = controller.isGrounded;

        Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
        controller.Move(move * Time.deltaTime * mSpeed);

        if (isGrounded && playerVelocity.y < 0)
        {
            playerVelocity.y = 0f;
        }

        /*
        Vector3 Dir = new Vector3(0, 0, 0);
        Dir.z = Input.GetAxis("Vertical");
        Dir.x = Input.GetAxis("Horizontal");
        transform.Translate(Dir * mSpeed * Time.deltaTime);
        */
    }     
    void jump()
    {

        if (Input.GetButton("Jump") && isGrounded)
        {

            playerVelocity.y += Mathf.Sqrt(jumpForce * -3.0f * gravityValue);
            doubleJump = true;


        }

        else
        {
            if (Input.GetButtonDown("Jump") && wallJump == true)
            {

                wallJump = false;
                playerVelocity.y += Mathf.Sqrt(jumpForce * -3.0f * gravityValue);

                Debug.Log("wall jump");

            }
            else
            {
                if (Input.GetButtonDown("Jump") && doubleJump == true)
                {

                    doubleJump = false;
                    playerVelocity.y += Mathf.Sqrt(jumpForce * -3.0f * gravityValue);


                }


            }
        }
    }
    void close()
    {

        if (Input.GetButtonDown("Cancel"))
        {
            Application.Quit();
            Debug.Log("Quit");
        }

    }

    Vector3 wallJumpVect = Vector3.zero;

    private void OnTriggerStay(Collider other)
    {

        if (other.CompareTag("Wall"))
        {

            wallJump = true;
            if (Input.GetButtonDown("Jump") && wallJump == true)
            {

                wallJump = false;
                wallJumpVect = -(other.ClosestPointOnBounds((transform.position) - transform.position).normalized * 5f);
                controller.Move(wallJumpVect);
                //playerVelocity -= wallJumpVect;
            }
        }

    }
    private void OnTriggerExit(Collider other)
    {

        wallJump = false;
        //playerVelocity += wallJumpVect;

    }

}

